const express = require("express");
const EmprestimoController = require("../controllers/emprestimoController");

const router = express.Router();
const ctrl = new EmprestimoController();

router.get("/", ctrl.emprestimoView); // Interface de Empréstimos
router.post("/emprestar", ctrl.realizarEmprestimo); // Confirmar Empréstimo

module.exports = router;
