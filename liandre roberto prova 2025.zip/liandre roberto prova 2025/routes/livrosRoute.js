const express = require("express");
const LivroController = require("../controllers/livroController");

const router = express.Router();

let ctrl = new LivroController
router.get("/cadastrar", ctrl.cadastrarView);
router.post("/cadastrar", ctrl.cadastrar);
router.delete("/excluir/:isbn", ctrl.deletar);
router.get("/", ctrl.listaView);
router.get("/:isbn", ctrl.obter);



module.exports = router;