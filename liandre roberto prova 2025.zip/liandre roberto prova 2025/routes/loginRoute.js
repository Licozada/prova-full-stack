const express = require("express");
const LoginController = require("../controllers/loginController");

const router = express.Router();

let ctrl = new LoginController();

// Rota para exibir a interface de login
router.get("/", ctrl.loginView);

// Rota para autenticar o usuário
router.post("/auth", ctrl.authenticateUser);

module.exports = router;