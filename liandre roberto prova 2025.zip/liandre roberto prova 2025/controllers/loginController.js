const UsuarioBibliotecaModel = require("../models/usuarioModel");


class LoginController {
    // Renderiza a página de login
    loginView(req, res) {
        res.render("login/index.ejs", { layout: false }); // Certifique-se de que a view de login está configurada corretamente
    }

    // Autentica o usuário com base no e-mail e senha
    authenticateUser(req, res) {
        try {
            // Obtenha os dados do corpo da requisição
            const { email, password } = req.body;
    
            // Adicione logs para verificar se os dados estão sendo recebidos corretamente
            console.log("E-mail recebido:", email);
            console.log("Senha recebida:", password);
    
            if (!email || !password) {
                return res.status(400).json({ ok: false, msg: "E-mail e senha são obrigatórios." });
            }
    
            const usuarioModel = new UsuarioBibliotecaModel();
    
            usuarioModel.obterPorEmailSenha(email, password)
                .then((usuario) => {
                    if (!usuario) {
                        console.log("Usuário não encontrado ou senha incorreta.");
                        return res.status(401).json({ ok: false, msg: "E-mail ou senha incorretos." });
                    }
    
                    console.log("Usuário encontrado:", usuario);
                    req.session.usuario = usuario.toJSON();
                    res.status(200).json({ ok: true, msg: "Login realizado com sucesso!" });
                })
                .catch((error) => {
                    console.error("Erro ao autenticar usuário:", error.message);
                    res.status(500).json({ ok: false, msg: "Erro ao processar o login. Tente novamente." });
                });
        } catch (error) {
            console.error("Erro inesperado no servidor:", error.message);
            res.status(500).json({ ok: false, msg: "Erro interno no servidor. Tente novamente." });
        }
    }
    
}

module.exports = LoginController;