const LivroModel = require("../models/livroModel");
const AutorModel = require("../models/autorModel"); // Importando o modelo de autor
const CategoriaModel = require("../models/categoriaModel"); // Importando o modelo de categoria

class LivroController {

    async listaView(req, res) {
        let l = new LivroModel();
        let lista = await l.listar();
        res.render('livros/listar.ejs', { livros: lista });
    }

    async obter(req, res) {
        let l = new LivroModel();
        let livro = await l.obter(req.params.isbn);
        res.send({ livro: livro });
    }

    async cadastrarView(req, res) {
        try {
            // Instância dos modelos de Autor e Categoria
            const autorModel = new AutorModel();
            const categoriaModel = new CategoriaModel();

            // Buscar os autores e categorias no banco de dados
            const autores = await autorModel.listar(); // Lista de autores
            const categorias = await categoriaModel.listar(); // Lista de categorias

            // Renderizar a página de cadastro com os autores e categorias
            res.render("livros/cadastrar.ejs", { autores, categorias });
        } catch (error) {
            console.error("Erro ao carregar autores e categorias:", error.message);
            res.status(500).send("Erro ao carregar a página de cadastro. Tente novamente.");
        }
    }

    async cadastrar(req, res) {
        try {
            let l = new LivroModel();
            const { isbn, titulo, autorId, categoriaId, anoPublicacao, quantidade, capaUrl } = req.body;

            let livroExistente = await l.obter(isbn);
            if (livroExistente) {
                return res.status(400).send('ISBN já cadastrado.');
            }

            await l.cadastrar({ isbn, titulo, autorId, categoriaId, anoPublicacao, quantidade, capaUrl });

            res.redirect('/livro');
        } catch (error) {
            console.error(error);
            res.status(500).send('Ocorreu um erro no servidor.');
        }
    }

    async deletar(req, res) {
        try {
            const l = new LivroModel();
            const { isbn } = req.params;

            // Verifica se o livro existe
            const livro = await l.obter(isbn);
            if (!livro) {
                return res.json({ ok: false, msg: "Livro não encontrado." });
            }

            // Valida a quantidade
            if (livro.quantidade > 0) {
                return res.json({
                    ok: false,
                    msg: "Não é possível excluir este livro. Ainda há exemplares disponíveis.",
                });
            }

            // Exclui o livro
            await l.deletar(isbn);
            return res.json({ ok: true, msg: "Livro excluído com sucesso!" });
        } catch (error) {
            console.error("Erro ao excluir livro:", error);
            return res.json({
                ok: false,
                msg: "Erro ao excluir o livro. Tente novamente.",
            });
        }
    }
}

module.exports = LivroController;
