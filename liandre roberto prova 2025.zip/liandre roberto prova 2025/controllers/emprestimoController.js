const LivroModel = require("../models/livroModel");

class EmprestimoController {
    // Renderiza a página de empréstimos
    emprestimoView(req, res) {
        res.render("emprestimo/index.ejs", { layout: false });
    }

    // Realiza o empréstimo de um livro com base no ISBN
    async realizarEmprestimo(req, res) {
        try {
            const { isbn } = req.body; // Obtém o ISBN enviado pelo frontend
            const livroModel = new LivroModel();

            // Valida e realiza o empréstimo, decrementando a quantidade
            const livro = await livroModel.obter(isbn); // Consulta os detalhes do livro

            if (!livro) {
                return res.status(404).json({ ok: false, msg: "Livro não encontrado." });
            }

            if (livro.quantidade <= 0) {
                return res.status(400).json({ ok: false, msg: "Não há exemplares disponíveis para empréstimo." });
            }

            // Decrementa a quantidade de exemplares disponíveis
            await livroModel.atualizarQuantidade(isbn, livro.quantidade - 1);

            res.status(200).json({ ok: true, msg: "Empréstimo realizado com sucesso!" });
        } catch (error) {
            console.error("Erro ao realizar empréstimo:", error.message);
            res.status(500).json({ ok: false, msg: "Erro ao realizar o empréstimo. Tente novamente." });
        }
    }
}

module.exports = EmprestimoController;