const Database = require("../db/database");

class LivroModel {
    #id;
    #isbn;
    #titulo;
    #anoPublicacao;
    #quantidade;
    #capaUrl;
    #autorId;
    #autorNome;
    #categoriaId;
    #categoriaNome;

    constructor(id, isbn, titulo, anoPublicacao, quantidade, capaUrl, autorId, autorNome, categoriaId, categoriaNome) {
        this.#id = id;
        this.#isbn = isbn;
        this.#titulo = titulo;
        this.#anoPublicacao = anoPublicacao;
        this.#quantidade = quantidade;
        this.#capaUrl = capaUrl;
        this.#autorId = autorId;
        this.#autorNome = autorNome;
        this.#categoriaId = categoriaId;
        this.#categoriaNome = categoriaNome;
    }

    // Getters
    get id() { return this.#id; }
    get isbn() { return this.#isbn; }
    get titulo() { return this.#titulo; }
    get anoPublicacao() { return this.#anoPublicacao; }
    get quantidade() { return this.#quantidade; }
    get capaUrl() { return this.#capaUrl; }
    get autorId() { return this.#autorId; }
    get categoriaId() { return this.#categoriaId; }
    get categoriaNome() { return this.#categoriaNome; }
    get autorNome() { return this.#autorNome; }

    // Setters
    set id(id) { this.#id = id; }
    set isbn(isbn) { this.#isbn = isbn; }
    set titulo(titulo) { this.#titulo = titulo; }
    set anoPublicacao(anoPublicacao) { this.#anoPublicacao = anoPublicacao; }
    set quantidade(quantidade) { this.#quantidade = quantidade; }
    set capaUrl(capaUrl) { this.#capaUrl = capaUrl; }
    set autorId(autorId) { this.#autorId = autorId; }
    set categoriaId(categoriaId) { this.#categoriaId = categoriaId; }
    set categoriaNome(categoriaNome) { this.#categoriaNome = categoriaNome; }
    set autorNome(autorNome) { this.#autorNome = autorNome; }

    // Listar todos os livros
    async listar() {
        const sql = `
            SELECT * FROM tb_livro l 
            INNER JOIN tb_categoria c ON l.cat_id = c.cat_id
            INNER JOIN tb_autor a ON l.aut_id = a.aut_id
        `;
        const banco = new Database();

        const rows = await banco.ExecutaComando(sql);
        const lista = rows.map(row => new LivroModel(
            row["liv_id"], row["liv_isbn"], row["liv_titulo"], row["liv_anopublicacao"],
            row["liv_quantidade"], row["liv_capaurl"], row["aut_id"], row["aut_nome"], 
            row["cat_id"], row["cat_nome"]
        ));

        return lista;
    }

    // Obter detalhes de um livro pelo ISBN
    async obter(isbn) {
        const sql = `
            SELECT * FROM tb_livro l 
            INNER JOIN tb_categoria c ON l.cat_id = c.cat_id
            INNER JOIN tb_autor a ON l.aut_id = a.aut_id
            WHERE liv_isbn = ?
        `;
        const banco = new Database();

        const rows = await banco.ExecutaComando(sql, [isbn]);

        if (rows.length > 0) {
            const row = rows[0];
            return new LivroModel(
                row["liv_id"], row["liv_isbn"], row["liv_titulo"], row["liv_anopublicacao"],
                row["liv_quantidade"], row["liv_capaurl"], row["aut_id"], row["aut_nome"], 
                row["cat_id"], row["cat_nome"]
            );
        }

        return null;
    }

    // Cadastrar um novo livro
    async cadastrar(livro) {
        const sql = `
            INSERT INTO tb_livro (liv_isbn, liv_titulo, liv_anopublicacao, liv_quantidade, liv_capaurl, aut_id, cat_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `;
        const banco = new Database();

        await banco.ExecutaComando(sql, [
            livro.isbn, livro.titulo, livro.anoPublicacao,
            livro.quantidade, livro.capaUrl, livro.autorId, livro.categoriaId
        ]);

        return true;
    }

    // Deletar um livro pelo ISBN
    async deletar(isbn) {
        const sql = "DELETE FROM tb_livro WHERE liv_isbn = ?";
        const banco = new Database();

        await banco.ExecutaComando(sql, [isbn]);
    }

    // Atualizar a quantidade de exemplares disponíveis
    async atualizarQuantidade(isbn, novaQuantidade) {
        const sql = "UPDATE tb_livro SET liv_quantidade = ? WHERE liv_isbn = ?";
        const banco = new Database();

        await banco.ExecutaComando(sql, [novaQuantidade, isbn]);
    }

    // Validar disponibilidade de exemplares de um livro
    async validarDisponibilidade(isbn) {
        const livro = await this.obter(isbn);
        if (!livro) {
            throw new Error("Livro não encontrado.");
        }

        if (livro.quantidade <= 0) {
            throw new Error("Não há exemplares disponíveis para empréstimo.");
        }

        return livro;
    }

    // Realizar empréstimo (decrementar exemplares disponíveis)
    async realizarEmprestimo(isbn) {
        const livro = await this.validarDisponibilidade(isbn);
        await this.atualizarQuantidade(isbn, livro.quantidade - 1);
    }

    // Serializar o objeto como JSON
    toJSON() {
        return {
            id: this.#id,
            isbn: this.#isbn,
            titulo: this.#titulo,
            anoPublicacao: this.#anoPublicacao,
            quantidade: this.#quantidade,
            capaUrl: this.#capaUrl,
            autorId: this.#autorId,
            autorNome: this.#autorNome,
            categoriaId: this.#categoriaId,
            categoriaNome: this.#categoriaNome
        };
    }
}

module.exports = LivroModel;
