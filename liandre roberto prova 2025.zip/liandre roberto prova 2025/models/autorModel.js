const Database = require("../db/database");

class AutorModel {
    #id;
    #nome;

    constructor(id, nome) {
        this.#id = id;
        this.#nome = nome;
    }

    get id() { return this.#id; }
    get nome() { return this.#nome; }
    set id(id) { this.#id = id; }
    set nome(nome) { this.#nome = nome; }

    async listar() {
        const sql = "SELECT aut_id, aut_nome FROM tb_autor";
        const banco = new Database();

        const rows = await banco.ExecutaComando(sql);
        return rows.map(row => new AutorModel(row["aut_id"], row["aut_nome"]));
    }
}

module.exports = AutorModel;
