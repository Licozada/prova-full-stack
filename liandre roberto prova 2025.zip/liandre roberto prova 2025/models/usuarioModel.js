const Database = require("../db/database");

class UsuarioBibliotecaModel {
    #id;
    #nome;
    #email;
    #senha;
    #ativo;

    constructor(id, nome, email, senha, ativo) {
        this.#id = id;
        this.#nome = nome;
        this.#email = email;
        this.#senha = senha;
        this.#ativo = ativo;
    }

    // Getters
    get id() { return this.#id; }
    get nome() { return this.#nome; }
    get email() { return this.#email; }
    get senha() { return this.#senha; }
    get ativo() { return this.#ativo; }

    // Setters
    set id(id) { this.#id = id; }
    set nome(nome) { this.#nome = nome; }
    set email(email) { this.#email = email; }
    set senha(senha) { this.#senha = senha; }
    set ativo(ativo) { this.#ativo = ativo; }

    // Método para buscar um usuário pelo e-mail e senha
    async obterPorEmailSenha(email, senha) {
        try {
            const sql = "SELECT * FROM tb_usuariobiblioteca WHERE usu_email = ? AND usu_senha = ? AND usu_ativo = TRUE";
            const banco = new Database();
            const rows = await banco.ExecutaComando(sql, [email, senha]);

            // Verifica se o usuário foi encontrado
            if (rows.length > 0) {
                const row = rows[0];
                return new UsuarioBibliotecaModel(
                    row["usu_id"], row["usu_nome"], row["usu_email"], 
                    row["usu_senha"], row["usu_ativo"]
                );
            }

            return null; // Retorna null se o usuário não for encontrado
        } catch (error) {
            console.error("Erro ao buscar usuário por email e senha:", error.message);
            throw new Error("Erro ao buscar o usuário. Por favor, tente novamente.");
        }
    }

    // Método para buscar um usuário pelo ID
    async obter(id) {
        try {
            const sql = "SELECT * FROM tb_usuariobiblioteca WHERE usu_id = ?";
            const banco = new Database();
            const rows = await banco.ExecutaComando(sql, [id]);

            // Verifica se o usuário foi encontrado
            if (rows.length > 0) {
                const row = rows[0];
                return new UsuarioBibliotecaModel(
                    row["usu_id"], row["usu_nome"], row["usu_email"], 
                    row["usu_senha"], row["usu_ativo"]
                );
            }

            return null; // Retorna null se o usuário não for encontrado
        } catch (error) {
            console.error("Erro ao buscar usuário por ID:", error.message);
            throw new Error("Erro ao buscar o usuário. Por favor, tente novamente.");
        }
    }

    /**
     * Converte a instância para um objeto JSON simples
     * (útil para salvar na sessão)
     */
    toJSON() {
        return {
            id: this.#id,
            nome: this.#nome,
            email: this.#email,
            ativo: this.#ativo,
        };
    }
}

module.exports = UsuarioBibliotecaModel;
