const Database = require("../db/database");

class CategoriaModel {
    #id;
    #nome;

    constructor(id, nome) {
        this.#id = id;
        this.#nome = nome;
    }

    get id() { return this.#id; }
    get nome() { return this.#nome; }
    set id(id) { this.#id = id; }
    set nome(nome) { this.#nome = nome; }

    async listar() {
        const sql = "SELECT cat_id, cat_nome FROM tb_categoria";
        const banco = new Database();

        const rows = await banco.ExecutaComando(sql);
        return rows.map(row => new CategoriaModel(row["cat_id"], row["cat_nome"]));
    }
}

module.exports = CategoriaModel;
