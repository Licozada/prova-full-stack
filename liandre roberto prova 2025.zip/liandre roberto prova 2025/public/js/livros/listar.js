document.addEventListener("DOMContentLoaded", function () {
    // Selecionar todos os botões de exclusão
    const btns = document.querySelectorAll(".btn-exclusao");

    // Adicionar evento de clique em cada botão
    for (let btn of btns) {
        btn.addEventListener("click", excluirLivro);
    }

    // Função para excluir o livro
    function excluirLivro() {
        console.log("Botão clicado!");
        const isbn = this.dataset.isbn;
        const titulo = this.dataset.titulo;

        // Exibe uma confirmação antes de excluir
        if (confirm(`Deseja realmente excluir o livro "${titulo}"?`)) {
            const that = this;
            fetch(`/livro/excluir/${isbn}`, {
                method: "DELETE",
            })
                .then((resposta) => {
                    return resposta.json();
                })
                .then((dados) => {
                    alert(dados.msg);
                    if (dados.ok) {
                        // Remove a linha da tabela
                        that.parentElement.parentElement.remove();
                    }
                })
                .catch((erro) => {
                    console.error("Erro ao excluir o livro:", erro);
                    alert("Erro ao excluir o livro. Tente novamente.");
                });
        }
    }
});