document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.querySelector("form");

    loginForm.addEventListener("submit", function (e) {
        e.preventDefault(); // Evita o envio padrão do formulário

        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;

        if (!email || !password) {
            alert("Por favor, preencha todos os campos.");
            return;
        }

        // Faz a requisição ao backend
        fetch('/login/auth', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password }), // Envia os valores corretamente
        })
            .then((response) => response.json())
            .then((data) => {
                if (data.ok) {
                    alert(data.msg);
                    window.location.href = "/"; // Redireciona para a página inicial
                } else {
                    alert(data.msg);
                }
            })
            .catch((error) => {
                console.error("Erro na requisição:", error);
                alert("Erro ao processar o login. Tente novamente.");
            });
    });
});
