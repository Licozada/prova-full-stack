document.addEventListener("DOMContentLoaded", function () {
    const isbnInput = document.getElementById('isbnInput');
    const botaoBuscar = document.getElementById('searchButton');
    const confirmarEmprestimo = document.getElementById('borrowButton');
    const errorMessage = document.getElementById('errorMessage');
    const successMessage = document.getElementById('successMessage');
    const bookInfo = document.getElementById('bookInfo');

    // Função para buscar livro pelo ISBN
    botaoBuscar.addEventListener('click', function () {
        const isbn = isbnInput.value.trim();

        if (!isbn) {
            showError("Por favor, informe o ISBN do livro.");
            return;
        }

        fetch('/livro/' + isbn)
            .then(function(resposta) {
                if (!resposta.ok) {
                    throw new Error("Livro não encontrado.");
                }
                return resposta.json();
            })
            .then(function(corpo) {
                exibirInfoLivro(corpo.livro);
            })
            .catch(function(e) {
                console.error(e);
                showError("Erro ao buscar o livro. Por favor, tente novamente.");
            });
    });

    // Exibe as informações do livro na interface
    function exibirInfoLivro(livro) {
        document.getElementById('bookTitle').textContent = livro.titulo;
        document.getElementById('bookAuthor').textContent = `Autor: ${livro.autorNome}`;
        document.getElementById('bookCategory').textContent = `Categoria: ${livro.categoriaNome}`;
        document.getElementById('bookYear').textContent = `Ano: ${livro.anoPublicacao}`;
        document.getElementById('bookCover').src = livro.capaUrl;

        bookInfo.classList.add('show'); // Exibe a seção de informações do livro
        hideMessages(); // Esconde mensagens anteriores
    }

    // Botão para confirmar empréstimo
    confirmarEmprestimo.addEventListener('click', function () {
        const isbn = isbnInput.value.trim();

        if (!isbn) {
            showError("Por favor, informe o ISBN do livro.");
            return;
        }

        fetch('/emprestimo/emprestar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ isbn }),
        })
        .then(function(resposta) {
            return resposta.json();
        })
        .then(function(corpo) {
            if (corpo.ok) {
                showSuccess(corpo.msg); // Exibe mensagem de sucesso
                bookInfo.classList.remove('show'); // Esconde as informações do livro
            } else {
                showError(corpo.msg); // Exibe mensagem de erro
            }
        })
        .catch(function(e) {
            console.error(e);
            showError("Erro ao realizar o empréstimo. Por favor, tente novamente.");
        });
    });

    function showError(message) {
        errorMessage.textContent = message;
        errorMessage.classList.add('show');
        successMessage.classList.remove('show');
    }

    function showSuccess(message) {
        successMessage.textContent = message;
        successMessage.classList.add('show');
        errorMessage.classList.remove('show');
    }

    function hideMessages() {
        errorMessage.classList.remove('show');
        successMessage.classList.remove('show');
    }
});
