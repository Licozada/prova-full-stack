const UsuarioBibliotecaModel = require("../models/usuarioModel");



class AutenticacaoMiddleware {
    async validar(req, res, next) {
        // Verifica se há um usuário na sessão
        if (req.session.usuario) {
            const usuarioId = req.session.usuario.id; // Obtém o ID do usuário da sessão
            const usuarioModel = new UsuarioBibliotecaModel();

            try {
                // Consulta o banco de dados para validar o usuário
                const usuario = await usuarioModel.obter(usuarioId);

                // Valida se o usuário existe no banco de dados
                if (usuario) {
                    // Valida se o usuário está ativo
                    if (usuario.ativo) {
                        // Passa o usuário autenticado para o próximo middleware/rota
                        res.locals.usuario = usuario;
                        return next();
                    } else {
                        return res.redirect("/login"); // Redireciona para login se inativo
                    }
                } else {
                    return res.redirect("/login"); // Redireciona se o usuário não for encontrado
                }
            } catch (error) {
                console.error("Erro ao validar o usuário:", error.message);
                return res.redirect("/login"); // Redireciona em caso de erro
            }
        } else {
            // Redireciona para login se não houver usuário na sessão
            return res.redirect("/login");
        }
    }
}

module.exports = AutenticacaoMiddleware;
